#!/system/bin/sh
MODDIR=${0%/*}
LOG=/data/local/tmp/rm11pro_gps_fix.log
echo "post-fs-data start $(date)" > "$LOG"

chown root:root "$MODDIR/izat.conf"
chmod 0644 "$MODDIR/izat.conf"
chcon u:object_r:vendor_configs_file:s0 "$MODDIR/izat.conf" >>"$LOG" 2>&1

umount /vendor/etc/izat.conf 2>/dev/null
if mount -o bind "$MODDIR/izat.conf" /vendor/etc/izat.conf >>"$LOG" 2>&1; then
    echo "bind mount /vendor/etc/izat.conf ok" >> "$LOG"
else
    echo "bind mount /vendor/etc/izat.conf failed" >> "$LOG"
fi

# Reset xtra.sqlite once on first install in case retry limit (6) was already reached
if [ ! -f "$MODDIR/.xtra_reset_done" ]; then
    if [ -f /data/vendor/location/xtra/xtra.sqlite ]; then
        cp -p /data/vendor/location/xtra/xtra.sqlite /data/vendor/location/xtra/xtra.sqlite.bak 2>/dev/null
        rm -f /data/vendor/location/xtra/xtra.sqlite
        echo "reset locked xtra.sqlite" >> "$LOG"
    fi
    touch "$MODDIR/.xtra_reset_done"
fi

echo "post-fs-data done $(date)" >> "$LOG"
